/**
 * @author mrdoob / http://mrdoob.com/
 */

THREE.Group = function () {

	THREE.Object3D.call( this );

	this.type = 'Group';

};

THREE.Group.prototype = Object.assign( Object.create( THREE.Object3D.prototype ), {

	constructor: THREE.Group

} );
